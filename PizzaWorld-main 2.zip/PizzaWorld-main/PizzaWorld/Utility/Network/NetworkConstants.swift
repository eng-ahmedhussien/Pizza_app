//
//  Constans.swift
//  PizzaWorld
//
//  Created by Osama on 10/19/20.
//

import Foundation

class NetworkConstants {
    static let baseUrl = "http://i0sa.com/pizza/"
}
