//
//  PIZZATextView.swift
//  PizzaWorld
//
//  Created by Osama on 10/17/20.
//

import UIKit

class PIZZATextView: NibLoadingView {

    @IBOutlet weak var textView: UITextView!

}
