//
//  PizzaOptions.swift
//  PizzaWorld
//
//  Created by Osama on 10/20/20.
//

import Foundation

class PizzaOptions {
    var name: String?
    
    init(name: String? = nil) {
        self.name = name
    }
    
}
